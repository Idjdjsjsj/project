
<link rel="stylesheet" href="./assets/fontawesome-free/css/all.min.css">
<link rel="stylesheet" href="./assets/css/bootstrap.min.css">
<link rel="stylesheet" href="./assets/DataTables/datatables.min.css">
<link rel="stylesheet" href="./assets/css/jquery-ui.min.css">
<link rel="stylesheet" href="./assets/css/custom.css">
<script src="./assets/js/jquery-3.6.0.min.js"></script>
<script src="./assets/js/popper.min.js"></script>
<script src="./assets/js/jquery-ui.js"></script>
<script src="./assets/js/bootstrap.min.js"></script>
<script src="./assets/DataTables/datatables.min.js"></script>
<script src="./assets/js/script.js"></script>
