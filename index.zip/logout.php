<?php
require_once("classes/URLshortener.php");

echo URLshortener::logout();