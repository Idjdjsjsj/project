<?php // include 'URLshortner.php';
include 'DBConnection.php';
 ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Toolx </title>
</head>

<body>
   <?php include "header.html"; ?>
      <div class="log-sign" style="--i: 1.8s">
        <a href="login.html" class="btn transparent">Log in</a>
        <a href="#" class="btn solid">Sign up</a>
        <div class="mode"></div>
        <script type="text/javascript">
          const log - sign = document.querySelector('.log-sign');
          const mode = document.querySelector('.mode');
          mode.onclick = function() {
            sec.classList.mode('dark')
          }
        </script>
      </div>
    </div>

    <div class="hamburger-menu-container">
      <div class="hamburger-menu">
        <div></div>
      </div>
    </div>
  </div>
</header>
<!--END NAVBAR-->

    <main>
        <section>
            <div class="overlay"></div>
        </section>
    </main>

</body>
</html>
