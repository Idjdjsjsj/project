
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Responsive Navbar</title>
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap');
    *{
        padding: 0;
        margin: 0;
        box-sizing: border-box;
    }
    body{
        font-family: 'Poppins', sans-serif;
        overflow: hidden;
        height: 100vh;
        width: 100%;
    }
    ul{
        list-style: none;
    }
    a{
        text-decoration: none;
    }
    header{
        position: sticky;
        top: 0px;
        background-color: #60b4df;
        width: 100%;
        z-index: 1000;
    }
    section{
        position: relative;
        height: calc(100vh - 3rem);
        width: 100%;
        background: url('img/bg.jpg') no-repeat top center / cover;
        overflow: hidden;
    }
    .overlay{
        position: absolute;
        width: 100%;
        height: 100%;
        top: 0;
        left: 0;
        background-color: rgb(56, 165, 238, 0.5);
    }
    .container{
        max-width: 65rem;     /*increse nav width*/
        padding: 0 2rem;
        margin: 0 auto;
        display: flex;
        position: relative;
    }
    .logo-container{
        flex: 1;
        display: flex;
        align-items: center;
    }
    .nav-btn{
        flex: 3;
        display: flex;
    }
    .nav-links{
        flex: 2;
    }
    .log-sign{
        display: flex;
        justify-content: center;
        align-items: center;
        flex: 1;
    }
    .logo{
        color: #fff;
        font-size: 1.1rem;
        font-weight: 600;
        letter-spacing: 2px;
        text-transform: uppercase;
        line-height: 3rem;
    }
    .logo-container span{
      display: inline-block;
      font-size: 3.5vw;
      font-weight: 1000px;
      position: relative;
      transform: translateY(-100vh);
      animation: fall 1.5s forwards;
    }
    @keyframes fall{
      100%{
        transform: translateY(0);
      }
    }
    .logo-container span:nth-child(2){
      animation-delay: 0.5s;
    }
    .logo-container span:nth-child(3){
      animation-delay: 1.2s;
    }
    .logo-container span:nth-child(4){
      animation-delay: 1.9s;
    }
    .logo-container span:nth-child(5){
      animation-delay: 2.5s;
    }
    .btn{
        display: inline-block;
        padding: .5rem 1.3rem;
        font-size: .8rem;
        border: 2px solid #fff;
        border-radius: 2rem;
        line-height: 1;
        margin: 0 .2rem;
        transition: .3s;
        text-transform: uppercase;
    }
    .btn.solid, .btn.transparent:hover{
        background-color: #fff;
        color: #69bde7;
    }
    .btn.transparent, .btn.solid:hover{
        background-color: transparent;
        color: #fff;
    }
    .nav-links > ul{
        display: flex;
        justify-content: center;
        align-items: center;
    }
    .nav-link{
        position: relative;
    }
    .nav-link > a{
        line-height: 3rem;
        color: #fff;
        padding: 0 .8rem;
        letter-spacing: 1px;
        font-size: .95rem;
        display: flex;
        align-items: center;
        justify-content: space-between;
        transition: .5s;
    }
    .nav-link > a > i{
        margin-left: .2rem;
    }
    .nav-link:hover > a{
        transform: scale(1.1);
    }
    .dropdown{
        position: absolute;
        top: 100%;
        left: 0;
        width: 10rem;
        transform: translateY(10px);
        opacity: 0;
        pointer-events: none;
        transition: .5s;
    }
    .dropdown ul{
        position: relative;
    }
    .dropdown-link > a{
        display: flex;
        background-color: #fff;
        color: #3498db;
        padding: .5rem 1rem;
        font-size: .9rem;
        align-items: center;
        justify-content: space-between;
        transition: .3s;
    }
    .dropdown-link:hover > a{
        background-color: #3498db;
        color: #fff;
    }
    .dropdown-link:not(:nth-last-child(2)){
        border-bottom: 1px solid #efefef;
    }
    .dropdown-link i{
        transform: rotate(-90deg);
    }
    .arrow{
        position: absolute;
        width: 11px;
        height: 11px;
        top: -5.5px;
        left: 32px;
        background-color: #fff;
        transform: rotate(45deg);
        cursor: pointer;
        transition: .3s;
        z-index: -1;
    }
    .dropdown-link:first-child:hover ~ .arrow{
        background-color: #3498db;
    }
    .dropdown-link{
        position: relative;
    }
    .nav-link:hover > .dropdown,
    .dropdown-link:hover > .dropdown{
        transform: translate(0, 0);
        opacity: 1;
        pointer-events: auto;
    }
    .hamburger-menu-container{
        flex: 1;
        display: none;
        align-items: center;
        justify-content: flex-end;
    }
    .hamburger-menu{
        width: 2.5rem;
        height: 2.5rem;
        display: flex;
        align-items: center;
        justify-content: flex-end;
    }
    .hamburger-menu div{
        width: 1.6rem;
        height: 3px;
        border-radius: 3px;
        background-color: #fff;
        position: relative;
        z-index: 1001;
        transition: .5s;
    }
    .hamburger-menu div:before,
    .hamburger-menu div:after{
        content: '';
        position: absolute;
        width: inherit;
        height: inherit;
        background-color: #fff;
        border-radius: 3px;
        transition: .5s;
    }
    .hamburger-menu div:before{
        transform: translateY(-7px);
    }
    .hamburger-menu div:after{
        transform: translateY(7px);
    }
    #check{
        position: absolute;
        top: 50%;
        right: 1.5rem;
        transform: translateY(-50%);
        width: 2.5rem;
        height: 2.5rem;
        z-index: 90000;
        cursor: pointer;
        opacity: 0;
        display: none;
    }
    #check:checked ~ .hamburger-menu-container .hamburger-menu div{
        background-color: transparent;
    }
    #check:checked ~ .hamburger-menu-container .hamburger-menu div:before{
        transform: translateY(0) rotate(-45deg);
    }
    #check:checked ~ .hamburger-menu-container .hamburger-menu div:after{
        transform: translateY(0) rotate(45deg);
    }
    @keyframes animation{
        from{
            opacity: 0;
            transform: translateY(15px);
        }
        to{
            opacity: 1;
            transform: translateY(0px);
        }
    }
    @media (max-width: 920px){
        .hamburger-menu-container{
            display: flex;
        }
        #check{
            display: block;
        }
        .nav-btn{
            position: fixed;
            height: calc(100vh - 3rem);
            top: 3rem;
            left: 0;
            width: 100%;
            background-color: #69bde7;
            flex-direction: column;
            align-items: center;
            justify-content: space-between;
            overflow-x: hidden;
            overflow-y: auto;
            transform: translateX(100%);
            transition: .65s;
        }
        #check:checked ~ .nav-btn{
            transform: translateX(0);
        }
        #check:checked ~ .nav-btn .nav-link,
        #check:checked ~ .nav-btn .log-sign{
            animation: animation .5s ease forwards var(--i);
        }
        .nav-links{
            flex: initial;
            width: 100%;
        }
        .nav-links > ul{
            flex-direction: column;
        }
        .nav-link{
            width: 100%;
            opacity: 0;
            transform: translateY(15px);
        }
        .nav-link > a{
            line-height: 1;
            padding: 1.6rem 2rem;
        }
        .nav-link:hover > a{
            transform: scale(1);
            background-color: #50a9d6;
        }
        .dropdown{
            position: initial;
            top: initial;
            left: initial;
            transform: initial;
            opacity: 1;
            pointer-events: auto;
            width: 100%;
            padding: 0;
            background-color: #3183ac;
            display: none;
        }
        .nav-link:hover > .dropdown,
        .dropdown-link:hover > .dropdown{
            display: block;
        }
        .nav-link:hover > a > i,
        .dropdown-link:hover > a > i{
            transform: rotate(360deg);
        }
        .dropdown-link > a{
            background-color: transparent;
            color: #fff;
            padding: 1.2rem 2rem;
            line-height: 1;
        }
        .dropdown-link:not(:nth-last-child(2)){
            border-bottom: none;
        }

        .arrow{
            z-index: 1;
            background-color: #69bde7;
            left: 10%;
            transform: scale(1.1) rotate(45deg);
            transition: .5s;
        }

        .nav-link:hover .arrow{
            background-color: #50a9d6;
        }

        .dropdown .dropdown .arrow{
            display: none;
        }

        .dropdown-link:hover > a{
            background-color: #3a91bd;
        }

        .dropdown-link:first-child:hover ~ .arrow{
            background-color: #50a9d6;
        }

        .nav-link > a > i{
            font-size: 1.1rem;
            transform: rotate(-90deg);
            transition: .7s;
        }

        .dropdown i{
            font-size: 1rem;
            transition: .7s;
        }

        .log-sign{
            flex: initial;
            width: 100%;
            padding: 1.5rem 1.9rem;
            justify-content: flex-start;
            opacity: 0;
            transform: translateY(15px);
        }
    }
    /*END NAVBAR*/
    .mode{
      float: right;
      background: #fff;
      width: 30px;
      height: 30px;
      border-radius: 50%;
      display: flex;
      justify-content: center;
      align-items: center;
      cursor: pointer;
      color: #2fa1ff;
    }
    .mode:before{
      content: '\f185';
      font-family: fontawesome;
    }
    header.dark .mode:before{
      content: '\f186';
    }
    /*section{
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    section .card{
      position: relative;
      width: 300px;
      height: 380px;
      background: #fff;
      box-shadow: 0 15px 25px rgba(0,0,0,0.025);
      border-radius: 16px;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    section .card .content,
    section .card .imgtext{
      display: flex;
      justify-content: center;
    }
    ul#buttons li {
    	width: 30px;
    	height: 30px;
    	line-height: 30px;
    	text-align: center;
    	box-sizing: border-box;
    	background: transparent;
    	border-radius: 12px;
    	position: relative;
    	overflow: hidden;
    	transition: .5s;
    	box-shadow: 0px 8px 16px -6px,
    				0px 0px 16px -6px;
    }

    ul#buttons li a {
    	display: block;
    	widows: 100%;
    	height: 100%;
    	font-size: 1.25em;
    	background: transparent;
    	transition: .5s;
    	animation: icon-out .5s forwards;
    	animation-timing-function: cubic-bezier(0.5, -0.6, 1, 1);
    }

    ul#buttons li:before {
    	content: "";
    	width: 90px;
    	height: 90px;
    	display: block;
    	position: absolute;
    	transform: rotate(-45deg) translate(-110%, -23px);
    	z-index: -2;
    	animation: back-out .5s forwards;
    	animation-timing-function: cubic-bezier(0.5, -0.6, 1, 1);
    }

    ul#buttons li:hover a {
    	animation: icon-in .5s forwards;
    	animation-timing-function: cubic-bezier(0, 0, 0.4, 1.6);
    }

    ul#buttons li:hover:before {
    	animation: back-in .5s forwards;
    	animation-timing-function: cubic-bezier(0, 0, 0.4, 1.6);
    }

    @keyframes back-in {
        0% { transform: rotate(-45deg) translate(-110%, -23px); }
    	80% { transform: rotate(-45deg) translate(5%, -23px); }
    	100% { transform: rotate(-45deg) translate(0%, -23px); }
    }

    @keyframes back-out {
        0% { transform: rotate(-45deg) translate(0%, -23px); }
    	20% { transform: rotate(-45deg) translate(5%, -23px); }
    	100% { transform: rotate(-45deg) translate(-110%, -23px); }
    }

    @keyframes icon-in {
        0% { font-size: 1em; }
    	80% { color: #fff; font-size: 1em; }
    	100% { color: #fff; font-size: 1em; }
    }

    @keyframes icon-out {
    	0% { color: #fff; font-size: 1em; }
    	20% { color: #fff; font-size: 1em; }
    	100% { font-size: 1em; }
    }*/

    .clearfix:after {
      visibility: hidden;
      display: block;
      font-size: 0;
      content: " ";
      clear: both;
      height: 0;
    }
    .ath-card {
      max-width: 580px;
      width: 100%;
      margin: 50px auto;
      background: #f3f3f3;
      font-size: 14px;
      line-height: 18px;
      color: #4d4d4d;
      box-shadow: 0px 1px 3px rgba(0,0,0,0.4);
      border-radius: 5px;
      overflow: hidden;
    }
    .ath-card .content {
      display: inline-block;
      float: left;
      width: 100%;
      padding: 10px;
    }
    .ath-card .content .portrait {
      position: relative;
      float: left;
      display: inline-block;
      width: 30%;
      padding-bottom: 30%;
      overflow: hidden;
      background-image: url("img/hunter2.jpg");
      background-size: cover;
      background-position: center;
    }

    .card-theme-2 .content .portrait {
      position: relative;
      float: left;
      display: inline-block;
      width: 30%;
      padding-bottom: 30%;
      overflow: hidden;
      background-image: url("img/png1.jpeg");
      background-size: cover;
      background-position: center;
    }

    .ath-card .content .portrait .greeting-wrap {
      position: absolute;
      width: 100%;
      height: 100%;
      opacity: 0;
      -webkit-animation-duration: 300ms;
              animation-duration: 300ms;
      text-align: center;
    }
    .ath-card .content .portrait .greeting-wrap .greeting {
      position: relative;
      margin-top: 95%;
      display: inline-block;
      max-width: 90%;
      background: #fff;
      border-radius: 3px;
      padding: 5px 10px;
      text-align: center;
      transition: 150ms all linear;
      transform: translate(0, -100%);
      line-height: 14px;
      font-size: 12px;
    }
    .ath-card .content .portrait .greeting-wrap .greeting:after {
      content: '';
      position: absolute;
      top: 0;
      left: 50%;
      width: 0;
      height: 0;
      border: 15px solid transparent;
      border-bottom-color: #fff;
      border-top: 0;
      border-left: 0;
      margin-left: 0;
      margin-top: -15px;
      z-index: 0;
    }
    .ath-card .content .portrait:before {
      content: '';
      position: absolute;
      top: 0;
      bottom: 0;
      right: 0;
      left: 0;
      transition: all 150ms linear;
    }
    .ath-card .content .details {
      float: left;
      display: inline-block;
      width: 70%;
      padding: 0px 15px;
    }
    .ath-card .content .details .name {
      margin: 4px 0px 0px 0px;
      font-size: 20px;
      line-height: 20px;
      color: #01a6ab;
      overflow: ellipsis;
      white-space: nowrap;
    }
    .ath-card .content .details .subtitle {
      color: #737373;
      overflow: ellipsis;
      white-space: nowrap;
    }
    .ath-card .content .details .description {
      border-top: 1px solid rgba(0,0,0,0.1);
      text-align: justify;
      margin: 5px 0px 0px 0px;
      padding: 5px 0px 0px 0px;
    }
    .ath-card .content .details .more {
      border-top: 1px solid rgba(0,0,0,0.1);
      margin: 5px 0px 0px 0px;
      padding: 5px 0px 0px 0px;
      font-size: 12px;
      text-align: left;
    }
    .ath-card .content .details .more a {
      color: #898989;
      text-decoration: none;
    }
    .ath-card .content .details .more a:hover {
      color: #01a6ab;
    }
    .ath-card .content .details .more .card-row {
      display: inline-block;
      position: relative;
      width: 100%;
      padding-top: 5px;
      float: left;
    }
    .ath-card .content .details .more .card-row .title-col {
      float: left;
      display: inline-block;
      width: 35%;
      min-width: 80px;
      font-weight: bold;
    }
    .ath-card .content .details .more .card-row .desc-col {
      float: left;
      display: inline-block;
      width: 65%;
      color: #898989;
    }
    .ath-card .footer {
      display: inline-block;
      float: left;
      background: #01a6ab;
      background: linear-gradient(45deg, #c632eb 0%, #01a6ab) 100%;
      width: 100%;
      font-size: 18px;
      padding: 10px;
      text-align: center;
    }
    .ath-card .footer a {
      text-decoration: none;
      color: rgba(255,255,255,0.75);
      transition: 150ms all linear;
    }
    .ath-card .footer a i {
      padding: 0px 5px;
      line-height: 24px;
    }
    .ath-card .footer a:hover {
      color: #fff;
    }
    .ath-card.card-hover .content .portrait .greeting-wrap {
      opacity: 1;
    }
    .ath-card.card-hover .content .portrait:before {
      background: rgba(0,0,0,0.2);
    }



    .ath-card.card-theme-2 {
      max-width: 500px;
      position: relative;
    }
    .ath-card.card-theme-2 .content {
      float: none;
      width: auto;
      padding: 10px 50px 10px 10px;
      overflow: hidden;
      height: 100%;
    }
    .ath-card.card-theme-2 .content .portrait {
      position: absolute;
      left: 0;
      top: 0;
      width: 30%;
      height: 100%;
    }
    .ath-card.card-theme-2 .content .portrait .greeting-wrap .greeting {
      position: absolute;
      bottom: 10px;
      margin-top: 0;
      width: 90%;
      transform: translate(-50%, 0);
    }
    .ath-card.card-theme-2 .content .details {
      margin-left: 30%;
      padding: 0px 15px 0px 30px;
    }
    .ath-card.card-theme-2 .footer {
      position: absolute;
      right: 0;
      top: 0;
      width: 40px;
      height: 100%;
    }
    .ath-card.card-theme-2 .footer .link-wrap {
      position: absolute;
      left: 0;
      top: 50%;
      width: 100%;
      transform: translate(0, -50%);
    }
    .ath-card.card-theme-3 {
      position: relative;
      max-width: 500px;
      overflow: hidden;
    }
    .ath-card.card-theme-3 .content {
      padding: 0 0 54px 0;
      position: relative;
      overflow: hidden;
    }
    .ath-card.card-theme-3 .content .portrait {
      position: absolute;
      width: 40%;
      height: 100%;
      margin: 0;
    }
    .ath-card.card-theme-3 .content .details {
      position: relative;
      margin-left: 40%;
      width: 60%;
      z-index: 1;
      padding: 10px 20px 10px 0px;
    }
    .ath-card.card-theme-3 .content .details .name,
    .ath-card.card-theme-3 .content .details .subtitle {
      display: block;
      text-align: right;
    }
    .ath-card.card-theme-3 .content .details .description,
    .ath-card.card-theme-3 .content .details .more {
      border-width: 0;
      text-align: right;
    }
    .ath-card.card-theme-3 .content .details:before {
      content: "";
      position: absolute;
      background: #f3f3f3;
      width: 50px;
      height: 150%;
      left: 0;
      top: 0;
      transform-origin: top right;
      transform: rotate(10deg);
      z-index: -1;
    }
    .ath-card.card-theme-3 .footer {
      position: absolute;
      width: 120%;
      bottom: 0px;
      left: -10%;
      z-index: 2;
      transform-origin: top right;
      transform: rotate(-2deg);
      text-align: right;
      padding: 0px 12% 10px;
    }
    .ath-card.card-theme-3 .footer .link-wrap {
      padding-top: 15px;
      transform-origin: top right;
      transform: rotate(2deg);
    }

    @media screen and (max-width: 767px) {
      .ath-card,
      .ath-card.card-theme-2,
      .ath-card.card-theme-3{
        width: 300px;
        max-width: 100%;
      }
      .ath-card .content,
      .ath-card.card-theme-2 .content,
      .ath-card.card-theme-3 .content{
        text-align: center;
      }
      .ath-card .content .portrait,
      .ath-card.card-theme-2 .content .portrait,
      .ath-card.card-theme-3 .content .portrait{
        float: none;
        width: 50%;
        padding-bottom: 50%;
        margin: 5px 0px;
      }
      .ath-card .content .details,
      .ath-card.card-theme-2 .content .details,
      .ath-card.card-theme-3 .content .details{
        width: 100%;
      }
      .ath-card.card-theme-2 .content {
        padding: 0px;
      }
      .ath-card.card-theme-2 .content .portrait {
        position: relative;
        width: 100%;
        padding-bottom: 100%;
        margin: 0;
      }
      .ath-card.card-theme-2 .content .details {
        margin-left: 0%;
        padding: 10px 25px 10px 25px;
      }
      .ath-card.card-theme-2 .footer {
        position: relative;
        width: 100%;
        height: auto;
        padding: 10px;
      }
      .ath-card.card-theme-2 .footer .link-wrap {
        position: relative;
        top: 0;
        transform: translate(0, 0);
      }
      .ath-card.card-theme-3 {
        width: 300px;
        max-width: 100%;
      }
      .ath-card.card-theme-3 .content {
        padding: 0 0 64px 0;
      }
      .ath-card.card-theme-3 .content .portrait {
        margin: 0;
        position: relative;
        width: 100%;
        padding-bottom: 100%;
        height: auto;
      }
      .ath-card.card-theme-3 .content .portrait .greeting {
        margin-top: 90%;
      }
      .ath-card.card-theme-3 .content .details {
        margin: 0;
        width: 100%;
        padding: 0px 20px 0px 20px;
      }
      .ath-card.card-theme-3 .content .details .name,
      .ath-card.card-theme-3 .content .details .subtitle {
        text-align: left;
      }
      .ath-card.card-theme-3 .content .details .description,
      .ath-card.card-theme-3 .content .details .more {
        text-align: left;
      }
      .ath-card.card-theme-3 .content .details:before {
        width: 150%;
        height: 50px;
        left: -25%;
        top: 0;
        transform-origin: top right;
        transform: rotate(6deg);
      }
      .ath-card.card-theme-3 .footer {
        transform: rotate(-6deg);
      }
      .ath-card.card-theme-3 .footer .link-wrap {
        transform: rotate(6deg);
        padding: 25px 10px 5px 10px;
      }
    }

    </style>
</head>

<body> <?php include 'header.html'; ?>
            <script type="text/javascript">
              const log - sign = document.querySelector('.log-sign');
              const mode = document.querySelector('.mode');
              mode.onclick = function() {
                sec.classList.mode('dark')
              }
            </script>
          </div>
        </div>

        <div class="hamburger-menu-container">
          <div class="hamburger-menu">
            <div></div>
          </div>
        </div>
      </div>
    </header>

<!--END NAVBAR-->



<section>
  <div class='ath-card card-theme-3 clearfix'>
    <div class='content'>
      <div class='portrait'>
        <div class='greeting-wrap animated'>
          <div class='greeting'>
            Hello!
          </div>
        </div>
      </div>
      <div class='details'>
        <h4 class='name'>
          Gaurav Jadav
        </h4>
        <span class='subtitle'>
          @Mr.Hunter
        </span>
        <div class='description'>
           Hello My Name Is Priyank Jivani You Can contect through email,instagram,facebook  etc.....
        </div>
        <div class='more'>
          <div class='card-row'>
            <div class='title-col'>
              <i class='fa fa-globe'></i>
              LOCATION
            </div>
            <div class='desc-col'>
              Botad, Gujrat, India.
            </div>
          </div>
          <div class='card-row'>
            <div class='title-col'>
              <i class='fa fa-envelope'></i>
              EMAIL
            </div>
            <div class='desc-col'>
              <a href=''>thuglife5233@gmail.com</a>
            </div>
          </div>
          <div class='card-row'>
            <div class='title-col'>
              <i class='fa fa-skype'></i>
              SKYPE
            </div>
            <div class='desc-col'>
              <a href='#'>Gaurav.Jadav5233</a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class='footer'>
      <div class='link-wrap'>
        <a href='https://m.facebook.com/100025942359397/'>
          <i class='fa fa-facebook'></i>
        </a>
        <a href='#'>
          <i class='fa fa-linkedin'></i>
        </a>
        <a href='#'>
          <i class='fa fa-twitter'></i>
        </a>
        <a href='https://www.instagram.com/its_mr.hunter/'>
          <i class='fa fa-instagram'></i>
        </a>
        <a href='#'>
          <i class='fa fa-quora'></i>
        </a>
      </div>
    </div>
  </div>

  <div class='ath-card card-theme-2 clearfix'>
    <div class='content'>
      <div class='portrait'>
        <div class='greeting-wrap animated'>
          <div class='greeting'>
            Hello!
          </div>
        </div>
      </div>
      <div class='details'>
        <h4 class='name'>
          Priyank Jivani
        </h4>
        <span class='subtitle'>
          Web Developer
        </span>
        <div class='description'>
          Hello My Name Is Priyank Jivani You Can contect through email,instagram,facebook  etc.....
        </div>
        <div class='more'>
          <div class='card-row'>
            <div class='title-col'>
              <i class='fa fa-globe'></i>
              LOCATION
            </div>
            <div class='desc-col'>
              Botad, Gujrat, India.
            </div>
          </div>
          <div class='card-row'>
            <div class='title-col'>
              <i class='fa fa-envelope'></i>
              EMAIL
            </div>
            <div class='desc-col'>
              <a href=''>priyankjivani48@gmail.com</a>
            </div>
          </div>
          <div class='card-row'>
            <div class='title-col'>
              <i class='fa fa-skype'></i>
              SKYPE
            </div>
            <div class='desc-col'>
              <a href='#'>Priyank.Jivani32</a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class='footer'>
      <div class='link-wrap'>
        <a href='#'>
          <i class='fa fa-facebook'></i>
        </a>
        <a href='#'>
          <i class='fa fa-linkedin'></i>
        </a>
        <a href='https//twitter.com/priyankjivani'>
          <i class='fa fa-twitter'></i>
        </a>
        <a href='https://www.instagram.com/its_mr.hunter/'>
          <i class='fa fa-instagram'></i>
        </a>
        <a href='#'>
          <i class='fa fa-quora'></i>
        </a>
      </div>
    </div>
  </div>
</section>

<script src="vanilla-tilt.min.js"></script>
<script type="text/javascript">
VanillaTilt.init(document.querySelector(".card-theme-2"), {
max: 25,
speed: 400
});
</script>
<script type="text/javascript">
VanillaTilt.init(document.querySelector(".card-theme-3"), {
max: 25,
speed: 400
});
</script>
</body>
</html>
